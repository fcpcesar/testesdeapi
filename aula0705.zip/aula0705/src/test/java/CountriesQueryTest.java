import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;

public class CountriesQueryTest {

    //String url = "Content-Type"," application/json" ;
    String body = "{\"query\":\"        query{\\r\\n            continents(filter:{\\r\\n                code:\\r\\n                {\\r\\n                    in:[\\\"AF\\\"]\\r\\n                }\\r\\n            })\\r\\n            {\\r\\n                code\\r\\n            }\\r\\n        }\\r\\n\",\"variables\":{}}";
    String bodyError = "{\"query\":\"\\r\\nquery{\\r\\n  (filter:{\\r\\n    code:\\r\\n    {\\r\\n      in:[\\\"AF\\\"]\\r\\n    }\\r\\n    })\\r\\n\\t{\\r\\n    code\\r\\n    }\\r\\n  }\\r\\n\",\"variables\":{}}";

    @Test
    public void shouldReturnStatus200AndTheRequiredFieldsContnets(){
       Response response = ContinentsRequest.postContinents(body, Constants.BASE_URL);
        response.
                then().
                assertThat().
                statusCode(200);
    }

    @Test
    public void shouldReturnStatus200AndRequiredFields(){
        Response response = ContinentsRequest.postContinents(body, Constants.BASE_URL);
        String value = RequestBase.getValueFromResponse(response, "data.continents[0].code");
        System.out.println(value);
        response.
                then().log().all().
                assertThat().statusCode(200).body("data.continents[0].code", equalTo(value));
    }

    @Test
    public void shouldReturnStatus400(){
        Response response = ContinentsRequest.postContinents(bodyError, Constants.BASE_URL);
        response.
                then().log().all().
                assertThat().statusCode(400);
    }

    @Test
    public void shouldReturnStatusElementType(){
        Response response = ContinentsRequest.postContinents(body, Constants.BASE_URL);
        String value = RequestBase.getValueFromResponse(response, "data.continents[0].code");
        System.out.println(value);
        response.
                then().log().all().
                //assertThat().statusCode(200).body("data.continents[0].code", equalTo(value));
                assertThat().body("data.continents[0].code", instanceOf(String.class));
    }
}
