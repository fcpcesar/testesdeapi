public class Constants
{
    public static final String BASE_URL = "https://countries.trevorblades.com/";
}
